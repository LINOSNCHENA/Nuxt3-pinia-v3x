const client_manifest = {
  "_taxes.HXE8vHB5.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "taxes.HXE8vHB5.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_vue.f36acd1f.Zljsde_m.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "vue.f36acd1f.Zljsde_m.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/@mdi/font/fonts/materialdesignicons-webfont.eot": {
    "resourceType": "font",
    "mimeType": "font/eot",
    "file": "materialdesignicons-webfont.kq_ClZaA.eot",
    "src": "node_modules/@mdi/font/fonts/materialdesignicons-webfont.eot"
  },
  "node_modules/@mdi/font/fonts/materialdesignicons-webfont.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "materialdesignicons-webfont.e5j8FT_3.ttf",
    "src": "node_modules/@mdi/font/fonts/materialdesignicons-webfont.ttf"
  },
  "node_modules/@mdi/font/fonts/materialdesignicons-webfont.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "materialdesignicons-webfont.D15t_tsC.woff",
    "src": "node_modules/@mdi/font/fonts/materialdesignicons-webfont.woff"
  },
  "node_modules/@mdi/font/fonts/materialdesignicons-webfont.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "materialdesignicons-webfont.6eb_lmTU.woff2",
    "src": "node_modules/@mdi/font/fonts/materialdesignicons-webfont.woff2"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "error-404.Sb-wOkIr.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_vue.f36acd1f.Zljsde_m.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue"
  },
  "error-404.qFGwA4uS.css": {
    "file": "error-404.qFGwA4uS.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "error-500.BQy6GsU-.js",
    "imports": [
      "_vue.f36acd1f.Zljsde_m.js",
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue"
  },
  "error-500.V0P2JAtD.css": {
    "file": "error-500.V0P2JAtD.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/nuxt/dist/app/entry.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "assets": [
      "materialdesignicons-webfont.kq_ClZaA.eot",
      "materialdesignicons-webfont.6eb_lmTU.woff2",
      "materialdesignicons-webfont.D15t_tsC.woff",
      "materialdesignicons-webfont.e5j8FT_3.ttf"
    ],
    "css": [
      "entry.eKf6KB5N.css"
    ],
    "dynamicImports": [
      "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue",
      "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue"
    ],
    "file": "entry.tgypeZH4.js",
    "isEntry": true,
    "src": "node_modules/nuxt/dist/app/entry.js",
    "_globalCSS": true
  },
  "entry.eKf6KB5N.css": {
    "file": "entry.eKf6KB5N.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "materialdesignicons-webfont.kq_ClZaA.eot": {
    "file": "materialdesignicons-webfont.kq_ClZaA.eot",
    "resourceType": "font",
    "mimeType": "font/eot"
  },
  "materialdesignicons-webfont.6eb_lmTU.woff2": {
    "file": "materialdesignicons-webfont.6eb_lmTU.woff2",
    "resourceType": "font",
    "mimeType": "font/woff2"
  },
  "materialdesignicons-webfont.D15t_tsC.woff": {
    "file": "materialdesignicons-webfont.D15t_tsC.woff",
    "resourceType": "font",
    "mimeType": "font/woff"
  },
  "materialdesignicons-webfont.e5j8FT_3.ttf": {
    "file": "materialdesignicons-webfont.e5j8FT_3.ttf",
    "resourceType": "font",
    "mimeType": "font/ttf"
  },
  "pages/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.JmbhJxRz.js",
    "imports": [
      "_taxes.HXE8vHB5.js",
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/index.vue"
  },
  "pages/xbaddeals.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "xbaddeals.LvS5dJNM.js",
    "imports": [
      "_taxes.HXE8vHB5.js",
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/xbaddeals.vue"
  },
  "xbaddeals.l6AZh6oz.css": {
    "file": "xbaddeals.l6AZh6oz.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/xexports.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "xexports.NWA68XKH.js",
    "imports": [
      "_taxes.HXE8vHB5.js",
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/xexports.vue"
  },
  "xexports.N8D5OwTJ.css": {
    "file": "xexports.N8D5OwTJ.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/ximports.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "ximports.mesYL8x5.js",
    "imports": [
      "_taxes.HXE8vHB5.js",
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/ximports.vue"
  },
  "ximports.YXnkHcLO.css": {
    "file": "ximports.YXnkHcLO.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/xoutputs.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "xoutputs.oI4jtBmt.js",
    "imports": [
      "_taxes.HXE8vHB5.js",
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/xoutputs.vue"
  },
  "xoutputs.VeNEa-V5.css": {
    "file": "xoutputs.VeNEa-V5.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  }
};

export { client_manifest as default };
