const interopDefault = r => r.default || r || [];
const styles = {
  "node_modules/nuxt/dist/app/entry.js": () => import('./_nuxt/entry-styles.wOZ2MdI-.mjs').then(interopDefault),
  "pages/ximports.vue": () => import('./_nuxt/ximports-styles.IMt9go0y.mjs').then(interopDefault),
  "pages/xoutputs.vue": () => import('./_nuxt/xoutputs-styles.Fla_cN7-.mjs').then(interopDefault),
  "pages/xbaddeals.vue": () => import('./_nuxt/xbaddeals-styles.BVXcG8tY.mjs').then(interopDefault),
  "pages/xexports.vue": () => import('./_nuxt/xexports-styles.fUsi3JBO.mjs').then(interopDefault),
  "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue": () => import('./_nuxt/error-404-styles.XRz1-5H_.mjs').then(interopDefault),
  "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue": () => import('./_nuxt/error-500-styles.vMIeuOQq.mjs').then(interopDefault)
};

export { styles as default };
