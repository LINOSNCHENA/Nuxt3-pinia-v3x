const TableExports_vue_vue_type_style_index_0_scoped_63fa2e9c_lang = ".table[data-v-63fa2e9c]{background-color:#b1ddd1}";

const xexportsStyles_fUsi3JBO = [TableExports_vue_vue_type_style_index_0_scoped_63fa2e9c_lang];

export { xexportsStyles_fUsi3JBO as default };
