import { useSSRContext, defineComponent, ref, computed, withCtx, unref, isRef, createVNode, createTextVNode } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrInterpolate, ssrRenderList } from 'vue/server-renderer';
import { m as myTaxeStore } from './taxes-gwibrbYv.mjs';
import { _ as _export_sfc, s as storeToRefs, V as VResponsive, b as VTextField, d as VBtn } from '../server.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'unhead';
import '@unhead/shared';
import 'vue-router';

const _sfc_main$2 = /* @__PURE__ */ defineComponent({
  __name: "DataDisplayments",
  __ssrInlineRender: true,
  setup(__props) {
    const inputVal = ref("");
    const filtersStore = myTaxeStore();
    const { addValueToImports } = filtersStore;
    const { addValueToOutputs } = filtersStore;
    const { addValueToBadDeals } = filtersStore;
    const { addValueToExports } = filtersStore;
    const { filterStarter } = storeToRefs(filtersStore);
    const handleButtonClick = () => {
      addValueToImports();
      addValueToExports();
      addValueToOutputs();
      addValueToBadDeals();
    };
    const imports = computed(() => filtersStore.ImportResults);
    const exportx = computed(() => filtersStore.ExportResults);
    const outputs = computed(() => filtersStore.OutputResults);
    const bads = computed(() => filtersStore.BadDealsResults);
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(_attrs)}>`);
      _push(ssrRenderComponent(VResponsive, {
        class: "mx-auto",
        "max-width": "394"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(VTextField, {
              modelValue: unref(inputVal),
              "onUpdate:modelValue": ($event) => isRef(inputVal) ? inputVal.value = $event : null,
              width: "140",
              clearable: "",
              label: "Enter export name",
              variant: "outlined"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(VBtn, {
              class: "text-white",
              block: "",
              color: "success",
              size: "large",
              type: "submit",
              variant: "elevated",
              onClick: ($event) => handleButtonClick()
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<span${_scopeId2}> + Add each four elements </span>`);
                } else {
                  return [
                    createVNode("span", null, " + Add each four elements ")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(VTextField, {
                modelValue: unref(inputVal),
                "onUpdate:modelValue": ($event) => isRef(inputVal) ? inputVal.value = $event : null,
                width: "140",
                clearable: "",
                label: "Enter export name",
                variant: "outlined"
              }, null, 8, ["modelValue", "onUpdate:modelValue"]),
              createVNode(VBtn, {
                class: "text-white",
                block: "",
                color: "success",
                size: "large",
                type: "submit",
                variant: "elevated",
                onClick: ($event) => handleButtonClick()
              }, {
                default: withCtx(() => [
                  createVNode("span", null, " + Add each four elements ")
                ]),
                _: 1
              }, 8, ["onClick"])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(` ========================|MEMBERS-OF-STAFFS|=========== <br> ${ssrInterpolate(unref(imports).length)} <br> ${ssrInterpolate(unref(exportx).length)} <br> ${ssrInterpolate(unref(outputs).length)} <br> ${ssrInterpolate(unref(bads).length)} <br> ${ssrInterpolate(unref(filterStarter))} <br> ========================|MEMBERS-OF-STAFFS|=========== </div>`);
    };
  }
});
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Menus/DataDisplayments.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const _sfc_main$1 = /* @__PURE__ */ defineComponent({
  __name: "DataEntryServices",
  __ssrInlineRender: true,
  setup(__props) {
    const store = myTaxeStore();
    const fetchData = async () => {
      await store.fetchImports();
      await store.fetchExports();
      await store.fetchOutputs();
      await store.fetchBadDeals();
    };
    const doubleDigitIndex = (index2) => {
      return index2 < 10 ? "0" + index2 : index2;
    };
    const dataOutputed = store.importData;
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(_attrs)}>`);
      _push(ssrRenderComponent(VResponsive, {
        class: "mx-auto",
        "max-width": "394"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(VBtn, {
              onClick: fetchData,
              class: "text-white",
              block: "",
              color: "blue",
              size: "large",
              type: "submit",
              "max-width": "200",
              variant: "elevated"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(` Search - Queue an Import-Order`);
                } else {
                  return [
                    createTextVNode(" Search - Queue an Import-Order")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(VBtn, {
                onClick: fetchData,
                class: "text-white",
                block: "",
                color: "blue",
                size: "large",
                type: "submit",
                "max-width": "200",
                variant: "elevated"
              }, {
                default: withCtx(() => [
                  createTextVNode(" Search - Queue an Import-Order")
                ]),
                _: 1
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(` ============================================================================================================= <ul><!--[-->`);
      ssrRenderList(unref(dataOutputed), (filter, i) => {
        _push(`<li>${ssrInterpolate(doubleDigitIndex(i + 1))} - ${ssrInterpolate(filter)}</li>`);
      });
      _push(`<!--]--></ul> ============================================================================================================= `);
      if (unref(dataOutputed)) {
        _push(`<p> Total outputed elements : ${ssrInterpolate(unref(dataOutputed).length)}</p>`);
      } else {
        _push(`<!---->`);
      }
      _push(` ============================================================================================================= <br></div>`);
    };
  }
});
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Menus/DataEntryServices.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const _sfc_main = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  const _component_menus_data_displayments = _sfc_main$2;
  const _component_menus_data_entry_services = _sfc_main$1;
  _push(`<div${ssrRenderAttrs(_attrs)}>`);
  _push(ssrRenderComponent(_component_menus_data_displayments, null, null, _parent));
  _push(ssrRenderComponent(_component_menus_data_entry_services, null, null, _parent));
  _push(`</div>`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const index = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender]]);

export { index as default };
