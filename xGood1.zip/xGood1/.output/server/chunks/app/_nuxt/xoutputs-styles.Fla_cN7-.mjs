const TableOutputs_vue_vue_type_style_index_0_scoped_b0c69252_lang = ".table[data-v-b0c69252]{background-color:#be8090}h2[data-v-b0c69252]{color:#333}";

const xoutputsStyles_Fla_cN7_ = [TableOutputs_vue_vue_type_style_index_0_scoped_b0c69252_lang];

export { xoutputsStyles_Fla_cN7_ as default };
