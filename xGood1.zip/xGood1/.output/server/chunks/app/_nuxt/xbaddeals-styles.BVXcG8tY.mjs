const TableBadDeals_vue_vue_type_style_index_0_scoped_6f60eca5_lang = ".table[data-v-6f60eca5]{background-color:#9797b2}";

const xbaddealsStyles_BVXcG8tY = [TableBadDeals_vue_vue_type_style_index_0_scoped_6f60eca5_lang];

export { xbaddealsStyles_BVXcG8tY as default };
