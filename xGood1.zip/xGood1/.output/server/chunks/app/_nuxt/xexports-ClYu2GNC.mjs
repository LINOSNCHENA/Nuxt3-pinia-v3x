import { ssrRenderAttrs, ssrRenderComponent, ssrInterpolate } from 'vue/server-renderer';
import { useSSRContext, defineComponent, reactive, ref, unref, withCtx, createVNode, toDisplayString } from 'vue';
import { m as myTaxeStore } from './taxes-gwibrbYv.mjs';
import { f as VDataTableVirtual, _ as _export_sfc } from '../server.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'unhead';
import '@unhead/shared';
import 'vue-router';

const _sfc_main$1 = /* @__PURE__ */ defineComponent({
  __name: "TableExports",
  __ssrInlineRender: true,
  setup(__props) {
    const store = myTaxeStore();
    const state = reactive({
      exported: store.exportData || []
    });
    const outputs = state.exported;
    const outputHeaders = ref([
      { title: "Index", color: "lightblue", key: "index" },
      { title: "Id", color: "lightblue", key: "id" },
      { title: "TitleX", class: "my-header-style", key: "title" },
      { title: "URL", color: "lightblue", key: "url" },
      { title: "ThumbNail", color: "lightblue", key: "thumbnailUrl" },
      { title: "AlbumId", color: "lightblue", key: "albumId" },
      { title: "Total-X", color: "lightblue", key: "total" }
    ]);
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(_attrs)} data-v-63fa2e9c>`);
      _push(ssrRenderComponent(VDataTableVirtual, {
        headers: outputHeaders.value,
        items: unref(outputs),
        "items-per-page": 5,
        height: "800",
        class: "uppercase-headers table"
      }, {
        [`header.body`]: withCtx(({ column }, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<td data-v-63fa2e9c${_scopeId}>${ssrInterpolate(column)}</td>`);
          } else {
            return [
              createVNode("td", null, toDisplayString(column), 1)
            ];
          }
        }),
        item: withCtx(({ item, index }, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<tr data-v-63fa2e9c${_scopeId}><td data-v-63fa2e9c${_scopeId}>${ssrInterpolate(index + 1)}</td><td data-v-63fa2e9c${_scopeId}>${ssrInterpolate(item.id)}</td><td data-v-63fa2e9c${_scopeId}>${ssrInterpolate(item.title)}</td><td data-v-63fa2e9c${_scopeId}>${ssrInterpolate(item.url)}</td><td data-v-63fa2e9c${_scopeId}>${ssrInterpolate(item.thumbnailUrl)}</td><td data-v-63fa2e9c${_scopeId}>${ssrInterpolate(item.albumId)}</td><td data-v-63fa2e9c${_scopeId}>${ssrInterpolate(Object.keys(item).length)}</td></tr>`);
          } else {
            return [
              createVNode("tr", null, [
                createVNode("td", null, toDisplayString(index + 1), 1),
                createVNode("td", null, toDisplayString(item.id), 1),
                createVNode("td", null, toDisplayString(item.title), 1),
                createVNode("td", null, toDisplayString(item.url), 1),
                createVNode("td", null, toDisplayString(item.thumbnailUrl), 1),
                createVNode("td", null, toDisplayString(item.albumId), 1),
                createVNode("td", null, toDisplayString(Object.keys(item).length), 1)
              ])
            ];
          }
        }),
        _: 2
      }, _parent));
      _push(`<p data-v-63fa2e9c>Total export elements : ${ssrInterpolate(unref(outputs).length)}</p><br data-v-63fa2e9c></div>`);
    };
  }
});
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/TableExports.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const MyComponent = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["__scopeId", "data-v-63fa2e9c"]]);
const _sfc_main = {
  __name: "xexports",
  __ssrInlineRender: true,
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(_attrs)}><h1>2 - EXPORTS DATA</h1><p>This is the about page content.</p>`);
      _push(ssrRenderComponent(MyComponent, null, null, _parent));
      _push(`</div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/xexports.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
