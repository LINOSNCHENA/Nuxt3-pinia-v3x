import { ssrRenderAttrs, ssrRenderComponent, ssrInterpolate } from 'vue/server-renderer';
import { useSSRContext, defineComponent, reactive, ref, unref, withCtx, createVNode, toDisplayString } from 'vue';
import { m as myTaxeStore } from './taxes-gwibrbYv.mjs';
import { f as VDataTableVirtual, _ as _export_sfc } from '../server.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'unhead';
import '@unhead/shared';
import 'vue-router';

const _sfc_main$1 = /* @__PURE__ */ defineComponent({
  __name: "TableOutputs",
  __ssrInlineRender: true,
  setup(__props) {
    const store = myTaxeStore();
    const state = reactive({
      outputs: store.outputData || []
    });
    const outputs = state.outputs;
    const outputHeaders = ref([
      { title: "Index", color: "lightblue", key: "index" },
      { title: "Id", color: "lightblue", key: "id" },
      { title: "NameX", class: "my-header-style", key: "name" },
      { title: "UserNameX", class: "my-header-style", key: "username" },
      { title: "EmailX", class: "my-header-style", key: "email" },
      { title: "Address", color: "lightblue", key: "address" },
      { title: "ZipCode", color: "lightblue", key: "zipcode" },
      { title: "Total-X", color: "lightblue", key: "height" }
    ]);
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(_attrs)} data-v-b0c69252>`);
      _push(ssrRenderComponent(VDataTableVirtual, {
        headers: outputHeaders.value,
        items: unref(outputs),
        "items-per-page": 5,
        height: "800",
        class: "uppercase-headers table"
      }, {
        [`header.body`]: withCtx(({ column }, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<td data-v-b0c69252${_scopeId}>${ssrInterpolate(column)}</td>`);
          } else {
            return [
              createVNode("td", null, toDisplayString(column), 1)
            ];
          }
        }),
        item: withCtx(({ item, index }, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<tr data-v-b0c69252${_scopeId}><td data-v-b0c69252${_scopeId}>${ssrInterpolate(index + 1)}</td><td data-v-b0c69252${_scopeId}>${ssrInterpolate(item.id)}</td><td data-v-b0c69252${_scopeId}>${ssrInterpolate(item.name)}</td><td data-v-b0c69252${_scopeId}>${ssrInterpolate(item.username)}</td><td data-v-b0c69252${_scopeId}>${ssrInterpolate(item.email)}</td><td data-v-b0c69252${_scopeId}>${ssrInterpolate(item.address.city)}</td><td data-v-b0c69252${_scopeId}>${ssrInterpolate(item.address.zipcode)}</td><td data-v-b0c69252${_scopeId}>${ssrInterpolate(Object.keys(item).length)}</td></tr>`);
          } else {
            return [
              createVNode("tr", null, [
                createVNode("td", null, toDisplayString(index + 1), 1),
                createVNode("td", null, toDisplayString(item.id), 1),
                createVNode("td", null, toDisplayString(item.name), 1),
                createVNode("td", null, toDisplayString(item.username), 1),
                createVNode("td", null, toDisplayString(item.email), 1),
                createVNode("td", null, toDisplayString(item.address.city), 1),
                createVNode("td", null, toDisplayString(item.address.zipcode), 1),
                createVNode("td", null, toDisplayString(Object.keys(item).length), 1)
              ])
            ];
          }
        }),
        _: 2
      }, _parent));
      _push(`<p data-v-b0c69252>Total output elements: ${ssrInterpolate(unref(outputs).length)}</p><br data-v-b0c69252></div>`);
    };
  }
});
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/TableOutputs.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const MyComponent = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["__scopeId", "data-v-b0c69252"]]);
const _sfc_main = {
  __name: "xoutputs",
  __ssrInlineRender: true,
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(_attrs)}><h1>3 - OUTPUT DATA</h1><p>This is the about page content.</p>`);
      _push(ssrRenderComponent(MyComponent, null, null, _parent));
      _push(`</div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/xoutputs.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
