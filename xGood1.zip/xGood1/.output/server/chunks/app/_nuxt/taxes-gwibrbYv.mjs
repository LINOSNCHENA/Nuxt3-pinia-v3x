import { e as defineStore } from '../server.mjs';

const taxeServices = {
  async sourceImports() {
    try {
      const response = await fetch("https://testapi.jasonwatmore.com/products");
      if (!response.ok) {
        throw new Error("Failed to fetch imports");
      }
      return await response.json();
    } catch (error) {
      console.error("Error fetching imports:", error);
      throw error;
    }
  },
  async sourceExports() {
    try {
      const response = await fetch(
        "https://jsonplaceholder.typicode.com/photos"
      );
      if (!response.ok) {
        throw new Error("Failed to fetch exports");
      }
      return await response.json();
    } catch (error) {
      console.error("Error fetching exports:", error);
      throw error;
    }
  },
  // ===================================================================================================||
  async sourceOutputs() {
    try {
      const response = await await fetch(
        "https://jsonplaceholder.typicode.com/users"
      );
      if (!response.ok) {
        throw new Error("Failed to fetch outputs");
      }
      return await response.json();
    } catch (error) {
      console.error("Error fetching outputs:", error);
      throw error;
    }
  },
  async sourceBadDeals() {
    try {
      const response = await fetch(
        "https://jsonplaceholder.typicode.com/todos"
      );
      if (!response.ok) {
        throw new Error("Failed to fetch bad-deals");
      }
      return await response.json();
    } catch (error) {
      console.error("Error fetching bad-deals:", error);
      throw error;
    }
  }
};
const myTaxeStore = defineStore("myTaxes", {
  state: () => ({
    importData: [],
    // Initialize as an empty array
    exportData: [],
    outputData: [],
    baddealData: [],
    filterStarter: ["Pumulo", "Thresa", "Gabriel", "Esepu", "Henry", "Dauti"]
  }),
  actions: {
    async fetchImports() {
      const data = await taxeServices.sourceImports();
      this.importData.push(data[0]);
    },
    async fetchExports() {
      const data = await taxeServices.sourceExports();
      this.exportData.push(data[0]);
    },
    async fetchOutputs() {
      const data = await taxeServices.sourceOutputs();
      this.outputData.push(data[0]);
    },
    async fetchBadDeals() {
      const data = await taxeServices.sourceBadDeals();
      this.baddealData.push(data[0]);
    },
    // ==========================================================================================
    async addValueToImports() {
      const data = await taxeServices.sourceImports();
      this.importData.push(data[0]);
    },
    async addValueToExports() {
      const data = await taxeServices.sourceExports();
      this.exportData.push(data[0]);
    },
    async addValueToOutputs() {
      const data = await taxeServices.sourceOutputs();
      this.outputData.push(data[0]);
    },
    async addValueToBadDeals() {
      const data = await taxeServices.sourceBadDeals();
      this.baddealData.push(data[0]);
    }
  },
  getters: {
    ImportResults: (state) => state.importData,
    ExportResults: (state) => state.exportData,
    OutputResults: (state) => state.outputData,
    BadDealsResults: (state) => state.baddealData
  }
});

export { myTaxeStore as m };
