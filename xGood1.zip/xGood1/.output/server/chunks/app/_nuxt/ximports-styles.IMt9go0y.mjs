const TableImports_vue_vue_type_style_index_0_scoped_4d136db4_lang = ".table[data-v-4d136db4]{background-color:#49845c}";

const ximportsStyles_IMt9go0y = [TableImports_vue_vue_type_style_index_0_scoped_4d136db4_lang];

export { ximportsStyles_IMt9go0y as default };
