import { ssrRenderAttrs, ssrRenderComponent, ssrInterpolate } from 'vue/server-renderer';
import { useSSRContext, defineComponent, reactive, ref, unref, withCtx, createVNode, toDisplayString } from 'vue';
import { m as myTaxeStore } from './taxes-gwibrbYv.mjs';
import { f as VDataTableVirtual, _ as _export_sfc } from '../server.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'unhead';
import '@unhead/shared';
import 'vue-router';

const _sfc_main$1 = /* @__PURE__ */ defineComponent({
  __name: "TableBadDeals",
  __ssrInlineRender: true,
  setup(__props) {
    const store = myTaxeStore();
    const state = reactive({
      badDeals: store.baddealData || []
    });
    const outputs = state.badDeals;
    const outputHeaders = ref([
      { title: "Index", color: "lightblue", key: "index" },
      { title: "Id", color: "lightblue", key: "id" },
      { title: "Title", color: "lightblue", key: "title" },
      { title: "Completed", color: "lightblue", key: "completed" },
      { title: "UserIdX", class: "my-header-style", key: "userid" },
      { title: "Total-X", color: "lightblue", key: "height" }
    ]);
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(_attrs)} data-v-6f60eca5>`);
      _push(ssrRenderComponent(VDataTableVirtual, {
        headers: outputHeaders.value,
        items: unref(outputs),
        "items-per-page": 5,
        height: "800",
        class: "uppercase-headers table"
      }, {
        [`header.body`]: withCtx(({ column }, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<td data-v-6f60eca5${_scopeId}>${ssrInterpolate(column)}</td>`);
          } else {
            return [
              createVNode("td", null, toDisplayString(column), 1)
            ];
          }
        }),
        item: withCtx(({ item, index }, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<tr data-v-6f60eca5${_scopeId}><td data-v-6f60eca5${_scopeId}>${ssrInterpolate(index + 1)}</td><td data-v-6f60eca5${_scopeId}>${ssrInterpolate(item.id)}</td><td data-v-6f60eca5${_scopeId}>${ssrInterpolate(item.title)}</td><td data-v-6f60eca5${_scopeId}>${ssrInterpolate(item.completed)}</td><td data-v-6f60eca5${_scopeId}>${ssrInterpolate(item.userId)}</td><td data-v-6f60eca5${_scopeId}>${ssrInterpolate(Object.keys(item).length)}</td></tr>`);
          } else {
            return [
              createVNode("tr", null, [
                createVNode("td", null, toDisplayString(index + 1), 1),
                createVNode("td", null, toDisplayString(item.id), 1),
                createVNode("td", null, toDisplayString(item.title), 1),
                createVNode("td", null, toDisplayString(item.completed), 1),
                createVNode("td", null, toDisplayString(item.userId), 1),
                createVNode("td", null, toDisplayString(Object.keys(item).length), 1)
              ])
            ];
          }
        }),
        _: 2
      }, _parent));
      if (unref(outputs)) {
        _push(`<p data-v-6f60eca5>Total baddeals elements : ${ssrInterpolate(unref(outputs).length)}</p>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<br data-v-6f60eca5></div>`);
    };
  }
});
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/TableBadDeals.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const MyComponent = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["__scopeId", "data-v-6f60eca5"]]);
const _sfc_main = {
  __name: "xbaddeals",
  __ssrInlineRender: true,
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(_attrs)}><h1>4 - BAD DEALS</h1><p>This is the about page content.</p>`);
      _push(ssrRenderComponent(MyComponent, null, null, _parent));
      _push(`</div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/xbaddeals.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
