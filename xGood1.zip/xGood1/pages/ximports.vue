<template>
    <div>
        <h1>1 - IMPORT DATA</h1>
        <p>This is the about page content.</p>
        <MyComponent />
    </div>
</template>


<script setup>
import MyComponent from '@/components/TableImports.vue';
</script>
