<template>
    <div>
        <h1>2 - EXPORTS DATA</h1>
        <p>This is the about page content.</p>
        <MyComponent />
    </div>
</template>

<script setup>
import MyComponent from '@/components/TableExports.vue';
</script>
