<template>
    <div>
        <h1>3 - OUTPUT DATA</h1>
        <p>This is the about page content.</p>
        <MyComponent />
    </div>
</template>


<script setup>
import MyComponent from '@/components/TableOutputs.vue';
</script>
