<template>
    <div>
        <h1>4 - BAD DEALS</h1>
        <p>This is the about page content.</p>
        <MyComponent />
    </div>
</template>

<script setup>
import MyComponent from '@/components/TableBadDeals.vue';
</script>
