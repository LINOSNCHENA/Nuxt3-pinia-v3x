<template>
  <div>
    <menus-data-displayments />
    <menus-data-entry-services />
  </div>
</template>
