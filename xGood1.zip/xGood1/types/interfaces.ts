
// ====================================================|1|

export interface BadDealItem {
  completed: boolean;
  id: number;
  title: string;
  userId: number;
};

// ====================================================|2|
