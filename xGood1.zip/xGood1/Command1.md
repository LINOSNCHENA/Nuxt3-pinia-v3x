#
## COMMON COMMANDS

npm update -g npm
npm cache clean --force

npm i -D vuetify vite-plugin-vuetify
npm i @mdi/font
npm i vuetify@next @mdi/font

npm i sass
npm install -D sass-loader sass

npm i @paro-paro/vite-plugin-vuetify-sass

## End
